<script type="text/javascript">
window.location="news/";
</script>
