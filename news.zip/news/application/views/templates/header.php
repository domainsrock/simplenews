<html>
        <head>
                <meta charset="utf-8">
                <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
                <meta name="description" content="">
                <meta name="author" content="Praveen Sahu, DomainsRock India">
                <meta name="generator" content="Jekyll v3.8.5">
                <title><?php echo $title; ?> - CodeIgniter Tutorial</title>
                <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous"/>
                <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
                <link rel="stylesheet" href="https://getbootstrap.com/docs/4.3/examples/offcanvas/offcanvas.css"/>
                <style>
                .bd-placeholder-img {
                  font-size: 1.125rem;
                  text-anchor: middle;
                  -webkit-user-select: none;
                  -moz-user-select: none;
                  -ms-user-select: none;
                  user-select: none;
                }

                @media (min-width: 768px) {
                  .bd-placeholder-img-lg {
                    font-size: 3.5rem;
                  }
                  .mainmenu { margin-left: 60px; }
                }
                </style>
        </head>
        <body class="bg-light">

          <nav class="navbar navbar-expand-lg fixed-top navbar-dark bg-dark">
            <a class="navbar-brand mr-auto mr-lg-0" href="http://localhost/news/">News</a>
            <button class="navbar-toggler p-0 border-0" type="button" data-toggle="offcanvas">
              <span class="navbar-toggler-icon"></span>
            </button>

            <div class="navbar-collapse offcanvas-collapse" id="navbarsExampleDefault">
              <ul class="navbar-nav mr-auto mainmenu">
                <li class="nav-item">
                  <a class="nav-link" href="http://localhost/news/">Home</a>
                </li>
                <li class="nav-item">
                  <a class="nav-link" href="http://localhost/news/news/">News</a>
                </li>
                <li class="nav-item">
                  <a class="nav-link" href="http://localhost/news/news/create/">Post</a>
                </li>
                <li class="nav-item">
                  <a class="nav-link" href="#">Switch account</a>
                </li>
              </ul>
              <form class="form-inline my-2 my-lg-0">
                <input class="form-control mr-sm-2" type="text" placeholder="Search" aria-label="Search">
                <button class="btn btn-outline-success my-2 my-sm-0" type="submit">Search</button>
              </form>
            </div>
          </nav>
          <main role="main" class="container" style="min-height: 540px">
            <div class="d-flex align-items-center p-3 my-3 text-white-50 bg-purple rounded shadow-sm">
              <img class="mr-3" src="https://cdn2.iconfinder.com/data/icons/boldico/71/news-paper-magazine-newspaper-journal-512.png" alt="" width="48" height="48">
              <div class="lh-100">
                <h6 class="mb-0 text-white lh-100"><?php echo $title; ?></h6>
                <small>No.1 News Channel Since Since 2019</small>
              </div>
            </div>

            <div class="my-3 p-3 bg-white rounded shadow-sm">
