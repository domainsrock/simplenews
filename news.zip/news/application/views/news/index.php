  <h6 class="border-bottom border-gray pb-2 mb-0">News</h6>
    <?php foreach ($news as $news_item): ?>
      <div class="media text-muted pt-3">
        <img src="https://cdn2.iconfinder.com/data/icons/boldico/71/news-paper-magazine-newspaper-journal-512.png" class="bd-placeholder-img mr-2 rounded" width="32px" height="32px"/>
        <p class="media-body pb-3 mb-0 small lh-125 border-bottom border-gray">
          <strong class="d-block text-gray-dark"><?php echo $news_item['title']; ?></strong>
          <?php echo $news_item['text']; ?> <small><a href="<?php echo site_url('news/'.$news_item['slug']); ?>">View More...</a></small>
        </p>
      </div>
    <?php endforeach; ?>
    <small class="d-block text-right mt-3">
      <a href="http://localhost/news/news/">More News</a>
    </small>
