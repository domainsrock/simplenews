    <h2 class="border-bottom border-gray pb-2 mb-0"><?php echo ''.$news_item['title'].''; ?></h2>
    <?php echo $news_item['text']; ?>
